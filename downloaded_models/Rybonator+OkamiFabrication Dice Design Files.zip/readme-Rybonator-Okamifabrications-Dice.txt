These dice are free for all to use. They were designed by Okamifabrications in coordination with Rybonator of YouTube. 

You are free to sell these dice on Etsy, all that you would like. You are free to really do anything with these dice, so just have fun with them. Thank you for supporting the work that I do on my channel.

If you do use/sell these dice, simply link to my YouTube channel - https://www.youtube.com/c/rybonator
Please also list Okamifabrications as the designer of the dice.

I hope that you have a fantastic day! :) 